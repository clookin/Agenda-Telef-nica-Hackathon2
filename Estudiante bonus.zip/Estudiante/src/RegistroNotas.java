
import java.util.ArrayList;
import java.util.Iterator;

public class RegistroNotas {
    private ArrayList<Estudiante> estudiantes = new ArrayList();

    public RegistroNotas() {
    }

    public void agregarEstudiante(Estudiante estudiante) {
        this.estudiantes.add(estudiante);
    }

    public double calcularPromedioGeneral() {
        double suma = 0.0;

        Estudiante estudiante;
        for(Iterator var3 = this.estudiantes.iterator(); var3.hasNext(); suma += estudiante.calcularPromedio()) {
            estudiante = (Estudiante)var3.next();
        }

        return suma / (double)this.estudiantes.size();
    }
}
