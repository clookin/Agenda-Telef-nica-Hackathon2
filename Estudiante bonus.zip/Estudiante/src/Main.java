public class Main {
    public static void main(String[] args) {

            RegistroNotas registro = new RegistroNotas();
            Estudiante estudiante1 = new Estudiante("Juan", 20);
            estudiante1.agregarNota(85.5);
            estudiante1.agregarNota(92.0);
            Estudiante estudiante2 = new Estudiante("Maria", 21);
            estudiante2.agregarNota(78.5);
            registro.agregarEstudiante(estudiante1);
            registro.agregarEstudiante(estudiante2);
            System.out.println("El promedio general es: " + registro.calcularPromedioGeneral());

    }

}



