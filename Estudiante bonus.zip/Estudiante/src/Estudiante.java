import java.util.ArrayList;

public class Estudiante {
        private String nombre;
        private int edad;
        private ArrayList<Double> notas;

        public Estudiante(String nombre, int edad) {
            this.nombre = nombre;
            this.edad = edad;
            this.notas = new ArrayList();
        }

        public void agregarNota(double nota) {
            this.notas.add(nota);
        }

        public double calcularPromedio() {
            double suma = 0.0;

            for(int i = 0; i < this.notas.size(); ++i) {
                suma += (Double)this.notas.get(i);
            }

            return suma / (double)this.notas.size();
        }
    }
